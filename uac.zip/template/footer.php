</div>
</div>
</section>

<script src="<?php echo $url; ?>/assets/vendor/jquery-3.6.0.min.js"></script>
<script src="<?php echo $url; ?>/assets/vendor/bootstrap/js/bootstrap.js"></script>
<script src="<?php echo $url; ?>/assets/vendor/popper.min.js"></script>
<script src="<?php echo $url; ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!--<script src="--><?php //echo $url; ?><!--/assets/js/app.js"></script>-->
<!--<script src="--><?php //echo $url; ?><!--/assets/js/dashboard.js"></script>-->
<script>
    let currentPage = location.href;
    $(".menu-item-link").each(function () {
        let links = $(this).attr('href');
        if(currentPage == links){
            $(this).addClass('active');
        }
    });

</script>

</body>
</html>
